package com.firstfewlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPostgresExample {
    public static void main(String [] argv){
        SpringApplication.run(SpringBootPostgresExample.class, argv);
    }
}
